<?php
// Połącz się z bazą danych (zmień dane na swoje)
$servername = "localhost";
$username = "root";
$password = "";
$database = "instelpro";

// Tworzymy połączenie
$conn = new mysqli($servername, $username, $password, $database);

// Sprawdzamy połączenie
if ($conn->connect_error) {
    die("Połączenie nieudane: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Przechwytujemy zawartość pola textarea
    $zawartosc = $_POST['exampleInputEmail1'];
    $wiadomosc = $_POST['exampleFormControlTextarea1'];

    // Przygotowujemy zapytanie SQL do wstawienia zawartości do bazy danych
    $sql = "INSERT INTO formularz (id, email, wiadomosc) VALUES (0, '$zawartosc', '$wiadomosc')";

    if ($conn->query($sql) === TRUE) {
        echo "Wiadomość została wpisana do bazy danych.";
    } else {
        echo "Błąd: " . $sql . "<br>" . $conn->error;
    }
}

// Zamykamy połączenie
$conn->close();
?>
