<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>InstelPro - Kontakt</title>
	<link rel="stylesheet" href="assets/demo.css">
	<link rel="stylesheet" href="assets/header.css">
	<link rel="stylesheet" href="assets/footer.css">
	<link rel="shortcut icon" type="x-icon" href="graphics/logo_3.svg">
	<script src="https://skrypt-cookies.pl/id/5f38df1c6cc985ad.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
	<body>
		<header class="header-basic">
			<div class="header-limiter">
				<h1><a href="index.html"><img src="graphics/logo.svg" alt="" srcset="" id="logo"></a></h1>
				<nav>
					<a href="index.html">Strona Główna</a>
					<a href="realizacje.html">Realizacje</a>
					<a href="kontakt.php" class="selected">Formularz Kontaktowy</a>
					<a href="#"><form id="languageForm" action="#" method="GET">
                        <select id="languageSelect" class="form-select" aria-label="Default select example">
                            <option value="pl" selected>PL</option>
                            <option value="en">EN</option>
                            <option value="de">DE</option>
                        </select>
                    </form>
                    
                    <script>
                        document.getElementById('languageSelect').addEventListener('change', function() {
                            var selectedLanguage = this.value;
                            if (selectedLanguage === 'pl') {
                                window.location.href = 'strona_pl.html';
                            } else if (selectedLanguage === 'en') {
                                window.location.href = 'strona_en.html';
                            } else if (selectedLanguage === 'de') {
                                window.location.href = 'strona_de.html';
                            }
                        });
                    </script></a>
					</nav>
			</div>
		</header>
		<div class="menu2">
            <h3>Skontaktuj się z nami!</h3>
            <form action="dane.php" method="post" id="formularz">
                <div class="mb-3">
                  <label for="exampleInputEmail1" class="form-label">Email address</label>
                  <input type="email" class="form-control" id="exampleInputEmail1" name="exampleInputEmail1" aria-describedby="emailHelp">
                  <div id="emailHelp" class="form-text">Wprowadz swój adres e-mail.</div>
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Wiadomość</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" name="exampleFormControlTextarea1" rows="6"></textarea>
                  </div>
                <div class="mb-3 form-check">
                  <input type="checkbox" class="form-check-input" id="exampleCheck1" required>
                  <label class="form-check-label" for="exampleCheck1">Check me out</label>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
              </form><br><br><br><br>

		</div>
		<footer class="footer text-black text-center">
			<div class="container">
			  <div class="row">
				<div class="col-md-6">
				  <p><img src="graphics/logo.svg" alt="" srcset="" id="logo"></p>
				</div>
				<div class="col-md-6">
				  <ul class="list-inline">
					<li class="list-inline-item">kontakt@twojafirma.com</li><br>
					<li class="list-inline-item">123-456-789</li>
				  </ul>
				</div>
			  </div>
			</div>
		  </footer>
		  
		  
		  
			  
		  
		<script src="script.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	</body>
</html>